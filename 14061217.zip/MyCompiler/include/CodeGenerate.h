#ifndef CODEGENERATE_H
#define CODEGENERATE_H


class CodeGenerate
{
    public:
        CodeGenerate();
        virtual ~CodeGenerate();
    protected:
    private:
};

#endif // CODEGENERATE_H
