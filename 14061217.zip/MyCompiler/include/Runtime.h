#ifndef RUNTIME_H
#define RUNTIME_H

#include <stack>

class Runtime {
    public:
    private:
        static stack<int> runtime_stack;//����ջ
};

#endif // RUNTIME_H
