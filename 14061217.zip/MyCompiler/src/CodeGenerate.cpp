#include "CodeGenerate.h"

CodeGenerate::CodeGenerate()
{
    //ctor
}

CodeGenerate::~CodeGenerate()
{
    //dtor
}
